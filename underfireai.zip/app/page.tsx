'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import {
  Flame,
  Brain,
  Target,
  Mic,
  Shield,
  Star,
  CheckCircle2,
  ArrowRight,
  Zap,
  BarChart3,
  Play,
  FileText,
  Briefcase,
  Users,
  Clock,
  TrendingUp,
  Award,
  Eye,
  Volume2,
  MessageSquare,
  Sparkles,
  Building2,
  HeartHandshake,
  Code2,
  Lightbulb,
} from 'lucide-react';

export default function LandingPage(): React.JSX.Element {
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent): void => {
      setMousePos({
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const coreFeatures = [
    {
      icon: Brain,
      title: 'Hidden Personality Interviewers',
      desc: 'Every AI interviewer has a unique personality, backstory, and interviewing style that you must discover through the conversation. Some are skeptical, some are friendly, some focus on details - just like real interviewers. This forces you to actually listen, adapt, and think on your feet.',
      highlight: true,
    },
    {
      icon: Target,
      title: 'Real-Time STAR Method Analysis',
      desc: 'As you speak, our AI analyzes your responses for the Situation-Task-Action-Result structure that interviewers look for. Get instant feedback on whether you\'re providing enough context, clearly explaining your actions, and quantifying your impact.',
    },
    {
      icon: Mic,
      title: 'Voice-Based Conversations',
      desc: 'Type or speak naturally with AI interviewers that respond in real-time. Voice mode captures the pressure of real interviews - reading answers is easy, but speaking them confidently under pressure is the skill you actually need.',
    },
    {
      icon: BarChart3,
      title: 'Deep Performance Analytics',
      desc: 'Track your progress across multiple dimensions: clarity, confidence, technical depth, structure, and impact. See your improvement over time, identify patterns in your weaknesses, and get data-driven insights on what to practice next.',
    },
    {
      icon: Shield,
      title: 'Company-Specific Preparation',
      desc: 'Different companies have different interview cultures. FAANG emphasizes leadership principles. Consulting firms want structured thinking. Startups value scrappiness. We tailor the interview style, questions, and evaluation criteria to match.',
    },
    {
      icon: Zap,
      title: 'Adaptive Difficulty System',
      desc: 'Start at your comfort level and grow. The AI dynamically adjusts difficulty based on your performance - pushing harder when you\'re ready, easing up when you\'re struggling. Four levels from Easy to Expert, with 10+ question depths.',
    },
  ];

  const interviewTypes = [
    { icon: MessageSquare, name: 'Behavioral', desc: 'STAR-method situational questions' },
    { icon: Code2, name: 'Technical', desc: 'System design & coding challenges' },
    { icon: Lightbulb, name: 'Case Study', desc: 'Business problem solving' },
    { icon: HeartHandshake, name: 'HR Screen', desc: 'Culture fit & motivation' },
    { icon: Users, name: 'Panel Mode', desc: 'Multiple interviewers at once' },
    { icon: Clock, name: 'Phone Screen', desc: 'Quick 15-30 min rounds' },
  ];

  const resumeFeatures = [
    {
      icon: Eye,
      title: 'Vulnerability Scanner',
      desc: 'Our AI scans your resume for red flags, gaps, and weaknesses that interviewers will probe. Know your weak points before the interview so you can prepare strong responses.',
    },
    {
      icon: TrendingUp,
      title: 'Resume Health Score',
      desc: 'Get an overall quality score with detailed breakdown. See how your resume compares and what specific improvements will have the biggest impact.',
    },
    {
      icon: Briefcase,
      title: 'Job Alignment Analysis',
      desc: 'Upload a job description and see exactly how your resume matches. Identify skill gaps, missing keywords, and get coaching on how to address each gap in your interview.',
    },
    {
      icon: Sparkles,
      title: 'Personalized Questions',
      desc: 'We generate interview questions based on YOUR resume and YOUR target job. Practice answering questions about your actual experience and projects.',
    },
  ];

  const howItWorks = [
    {
      step: '01',
      title: 'Upload Your Resume',
      desc: 'Our AI extracts your skills, experience, and target role. We identify your strengths and areas where you\'ll need to prepare stronger stories.',
    },
    {
      step: '02',
      title: 'Choose Your Interview Type',
      desc: 'Select from behavioral, technical, case study, HR screen, or panel interviews. Pick your target company type and difficulty level.',
    },
    {
      step: '03',
      title: 'Face a Hidden Personality',
      desc: 'You\'ll be matched with an AI interviewer whose personality you must discover. Are they detail-oriented? Big-picture focused? Skeptical? Adapt and respond.',
    },
    {
      step: '04',
      title: 'Get Brutally Honest Feedback',
      desc: 'After each session, receive detailed scoring on clarity, confidence, structure, and impact. See exactly what worked, what didn\'t, and why.',
    },
    {
      step: '05',
      title: 'Track Your Progress',
      desc: 'Watch your scores improve over time. Build streaks, unlock achievements, and see data-driven evidence of your growth.',
    },
  ];

  const companyTypes = [
    { name: 'FAANG', icon: Building2, desc: 'Amazon, Google, Meta, Apple, Netflix' },
    { name: 'Startups', icon: Zap, desc: 'Series A-C growth companies' },
    { name: 'Consulting', icon: Briefcase, desc: 'McKinsey, BCG, Bain style' },
    { name: 'Finance', icon: TrendingUp, desc: 'Banks, hedge funds, PE firms' },
    { name: 'Enterprise', icon: Building2, desc: 'Fortune 500 corporations' },
    { name: 'Government', icon: Shield, desc: 'Public sector & contractors' },
  ];

  const testimonials = [
    {
      quote: "I was skeptical about AI interview prep, but UnderFireAI is different. The hidden personality feature forced me to actually listen and adapt instead of just reciting memorized answers. Landed Google L5 after failing twice before.",
      author: "Sarah Chen",
      role: "Senior SWE, Google",
      initials: "SC",
      result: "2 weeks prep → Google offer"
    },
    {
      quote: "The feedback is brutal but honest. After two weeks of daily practice, I went from fumbling behavioral questions to nailing them with structured, impactful stories. Got competing offers from Meta and Stripe.",
      author: "Marcus Johnson",
      role: "Staff PM, Meta",
      initials: "MJ",
      result: "3 competing offers"
    },
    {
      quote: "Voice mode changed everything. Reading answers is easy - speaking them under pressure is hard. The real-time STAR analysis helped me structure my responses naturally. Netflix DS offer on my first try.",
      author: "Priya Patel",
      role: "Data Scientist, Netflix",
      initials: "PP",
      result: "First attempt success"
    },
    {
      quote: "The resume vulnerability scanner found gaps I didn't even know I had. I prepared stories for every weak point before my Amazon loop. L6 offer with a signing bonus.",
      author: "David Kim",
      role: "SDE III, Amazon",
      initials: "DK",
      result: "Addressed all weak points"
    },
    {
      quote: "Panel mode simulating a consulting case interview was invaluable. Having multiple AI interviewers with different personalities taught me to read the room. McKinsey associate offer.",
      author: "Elena Rodriguez",
      role: "Associate, McKinsey",
      initials: "ER",
      result: "Consulting prep success"
    },
    {
      quote: "I used the job alignment feature to prep for a specific role at Stripe. The AI generated questions based on the exact job description. Felt like I had the interview questions in advance.",
      author: "James Wilson",
      role: "Engineering Manager, Stripe",
      initials: "JW",
      result: "Role-specific preparation"
    },
  ];

  const results = [
    { metric: '94%', label: 'Success Rate', sub: 'Of active users land offers within 3 months' },
    { metric: '2.3x', label: 'Faster Prep', sub: 'Compared to traditional coaching methods' },
    { metric: '50K+', label: 'Mock Interviews', sub: 'Completed on the platform to date' },
    { metric: '4.9/5', label: 'User Rating', sub: 'Based on 10,000+ verified reviews' },
  ];

  const pricing = [
    {
      name: 'Starter',
      price: '0',
      period: 'forever free',
      desc: 'Try the core experience',
      features: [
        '5 AI mock interviews per month',
        'Text-based practice only',
        'Basic STAR method feedback',
        'Standard difficulty levels',
        'Progress tracking dashboard',
      ],
      limitations: [
        'No voice mode',
        'Limited personality types',
        'No resume analysis',
      ],
      cta: 'Start Free',
      highlight: false,
    },
    {
      name: 'Pro',
      price: '29',
      period: 'per month',
      desc: 'For serious job seekers',
      features: [
        'Unlimited AI interviews',
        'Full voice mode with real-time response',
        'All 20+ interviewer personalities',
        'Advanced analytics & score tracking',
        'Resume vulnerability scanner',
        'Job description alignment analysis',
        'Company-specific interview styles',
        'All interview types & difficulty levels',
        'Priority support',
      ],
      limitations: [],
      cta: 'Start 7-Day Free Trial',
      highlight: true,
    },
    {
      name: 'Premium',
      price: '79',
      period: 'per month',
      desc: 'Maximum preparation',
      features: [
        'Everything in Pro, plus:',
        'Mock panel interviews (multiple interviewers)',
        '1-on-1 strategy session with interview coach',
        'Custom scenario builder',
        'Full interview recordings & replay',
        'Salary negotiation prep module',
        'Dedicated success manager',
        'Custom interviewer personality creation',
      ],
      limitations: [],
      cta: 'Go Premium',
      highlight: false,
    },
  ];

  const faqs = [
    {
      q: 'How is this different from practicing with ChatGPT?',
      a: 'UnderFireAI is purpose-built for interview prep with features ChatGPT can\'t offer: hidden interviewer personalities that force adaptive thinking, real-time STAR method analysis, voice mode with natural conversation flow, performance tracking over time, and resume-aware question generation. It\'s the difference between a generic chatbot and a specialized training system.',
    },
    {
      q: 'What are "hidden personalities" and why do they matter?',
      a: 'Each AI interviewer has a unique personality (skeptical, friendly, detail-oriented, big-picture, etc.) that you discover through the conversation - just like real interviews. This prevents you from memorizing answers and forces you to actually listen, read social cues, and adapt your communication style. It\'s the closest thing to real interview pressure.',
    },
    {
      q: 'How does voice mode work?',
      a: 'Speak naturally into your microphone and our AI responds in real-time, creating a conversational flow like a real interview. Voice mode is crucial because interviews test verbal communication, not typing. Many users find they can write great answers but struggle to deliver them verbally under pressure.',
    },
    {
      q: 'Can I prepare for a specific company or role?',
      a: 'Yes. Select your target company type (FAANG, startup, consulting, etc.) to get matching interview styles. Upload a job description for alignment analysis that shows skill gaps and generates role-specific questions. Upload your resume to get questions about your actual experience.',
    },
    {
      q: 'How does the STAR method analysis work?',
      a: 'As you answer behavioral questions, our AI analyzes your response in real-time for Situation (context), Task (your responsibility), Action (what you did), and Result (measurable outcome). You get instant feedback on missing elements, weak areas, and suggestions for improvement.',
    },
    {
      q: 'Is my data secure?',
      a: 'Your resume, interview recordings, and personal data are encrypted and never shared. We don\'t sell data or use it for advertising. You can delete your account and all associated data at any time.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#3D3229] antialiased overflow-x-hidden">
      {/* Subtle warm gradient background */}
      <div
        className="fixed inset-0 z-0 transition-all duration-500 ease-out pointer-events-none"
        style={{
          background: `radial-gradient(1000px circle at ${mousePos.x}% ${mousePos.y}%, rgba(139,90,43,0.04), transparent 40%)`,
        }}
      />

      {/* Static warm gradients */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-bl from-[#D4A574]/10 to-transparent blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-[#8B5A2B]/8 to-transparent blur-3xl" />
        <div className="absolute top-1/2 left-1/4 w-[400px] h-[400px] bg-gradient-to-br from-[#C4956A]/6 to-transparent blur-3xl" />
      </div>

      {/* Subtle grid pattern */}
      <div
        className="fixed inset-0 z-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(rgba(61,50,41,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(61,50,41,0.5) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4 bg-[#FAF8F5]/80 backdrop-blur-xl border-b border-[#3D3229]/5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A] rounded-xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity" />
              <div className="relative p-2.5 rounded-xl bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A]">
                <Flame className="h-5 w-5 text-white" />
              </div>
            </div>
            <span className="font-semibold text-lg tracking-tight text-[#3D3229]">UnderFireAI</span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {['Features', 'How It Works', 'Pricing', 'FAQ'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                className="px-4 py-2 text-sm text-[#6B5744] hover:text-[#3D3229] transition-colors"
              >
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <Link href="/login" className="px-4 py-2 text-sm text-[#6B5744] hover:text-[#3D3229] transition-colors">
              Sign in
            </Link>
            <Link
              href="/register"
              className="px-5 py-2.5 text-sm font-medium rounded-xl bg-gradient-to-r from-[#8B5A2B] to-[#5D3A1A] text-white hover:from-[#9A6B3C] hover:to-[#6B4420] transition-all shadow-lg shadow-[#8B5A2B]/20"
            >
              Get Started Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section ref={heroRef} className="relative min-h-screen flex items-center pt-24 pb-20 px-6">
        <div className="relative z-10 max-w-7xl mx-auto w-full">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#8B5A2B]/10 border border-[#8B5A2B]/20 mb-8">
                <div className="w-2 h-2 rounded-full bg-[#8B5A2B] animate-pulse" />
                <span className="text-sm text-[#6B5744]">AI-powered interview coaching</span>
              </div>

              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight mb-6">
                <span className="text-[#3D3229]">Train Under Fire.</span>
                <br />
                <span className="bg-gradient-to-r from-[#8B5A2B] via-[#A0522D] to-[#CD853F] bg-clip-text text-transparent">
                  So the real thing feels easy.
                </span>
              </h1>

              <p className="text-xl text-[#6B5744] leading-relaxed max-w-xl mb-8">
                Practice with AI interviewers who have <strong className="text-[#3D3229]">hidden personalities</strong> you
                must discover. Get <strong className="text-[#3D3229]">real-time STAR analysis</strong>, brutal feedback,
                and track your improvement over time.
              </p>

              <p className="text-lg text-[#8B7355] mb-10">
                Used by engineers, PMs, and consultants to land offers at Google, Meta, Amazon, McKinsey, and 500+ other companies.
              </p>

              <div className="flex flex-wrap items-center gap-4 mb-12">
                <Link
                  href="/register"
                  className="group inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#8B5A2B] to-[#5D3A1A] text-white text-base font-semibold hover:from-[#9A6B3C] hover:to-[#6B4420] transition-all shadow-xl shadow-[#8B5A2B]/25 hover:shadow-[#8B5A2B]/40 hover:-translate-y-0.5"
                >
                  Start Free Trial
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
                </Link>
                <button className="inline-flex items-center gap-2 px-7 py-4 rounded-xl text-base font-medium text-[#5D3A1A] border-2 border-[#8B5A2B]/30 hover:border-[#8B5A2B]/50 hover:bg-[#8B5A2B]/5 transition-all">
                  <Play className="h-4 w-4" />
                  Watch Demo
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-8">
                <div className="flex -space-x-3">
                  {['SC', 'MJ', 'PP', 'DK', 'ER'].map((initials, i) => (
                    <div
                      key={initials}
                      className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C4956A] to-[#8B5A2B] border-2 border-[#FAF8F5] flex items-center justify-center text-xs font-medium text-white"
                      style={{ zIndex: 5 - i }}
                    >
                      {initials}
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {Array.from({ length: 5 }, (_, i) => (
                      <Star key={i} className="h-4 w-4 fill-[#D4A574] text-[#D4A574]" />
                    ))}
                  </div>
                  <span className="text-sm text-[#6B5744]">
                    <span className="text-[#3D3229] font-medium">4.9/5</span> from 10,000+ users
                  </span>
                </div>
              </div>
            </div>

            {/* Hero card - Interview UI preview */}
            <div className="hidden lg:block">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-[#8B5A2B]/15 to-[#D4A574]/15 rounded-3xl blur-2xl" />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl border border-[#3D3229]/10 p-6 shadow-2xl shadow-[#8B5A2B]/10">
                  <div className="flex items-center gap-4 pb-5 border-b border-[#3D3229]/10">
                    <div className="relative">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A] flex items-center justify-center text-xl font-bold text-white">
                        AI
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-green-500 border-2 border-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-[#3D3229]">Technical Interviewer</p>
                      <p className="text-sm text-[#8B7355]">Senior Engineering • Hidden: ???</p>
                    </div>
                    <div className="ml-auto px-3 py-1 rounded-full bg-[#8B5A2B]/10 text-xs font-medium text-[#8B5A2B]">
                      Personality: Discover it
                    </div>
                  </div>

                  <div className="py-5 space-y-4">
                    <div className="bg-[#FAF8F5] rounded-2xl rounded-tl-sm p-4 max-w-[90%]">
                      <p className="text-sm text-[#3D3229] leading-relaxed">
                        &ldquo;Tell me about a time you had to make a critical technical decision with incomplete information.
                        Walk me through your thought process.&rdquo;
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#8B7355]">
                      <div className="w-2 h-2 rounded-full bg-[#8B5A2B] animate-pulse" />
                      STAR Analysis: Listening for Situation...
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#3D3229]/10">
                    <div className="flex items-center gap-3 bg-[#FAF8F5] rounded-xl px-4 py-3">
                      <Mic className="h-5 w-5 text-[#8B5A2B]" />
                      <span className="text-sm text-[#8B7355]">Press to respond with voice...</span>
                      <div className="ml-auto flex items-center gap-1">
                        <Volume2 className="h-4 w-4 text-[#8B5A2B]" />
                        <span className="text-xs text-[#8B5A2B] font-medium">Voice Mode</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-4 gap-3">
                    {[
                      { label: 'Clarity', score: 87, color: 'text-green-600' },
                      { label: 'Structure', score: 72, color: 'text-[#D4A574]' },
                      { label: 'Impact', score: 91, color: 'text-green-600' },
                      { label: 'Confidence', score: 68, color: 'text-[#CD853F]' },
                    ].map((item) => (
                      <div key={item.label} className="bg-[#FAF8F5] rounded-xl p-3 text-center">
                        <p className={`text-lg font-bold ${item.color}`}>{item.score}</p>
                        <p className="text-xs text-[#8B7355]">{item.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Results bar */}
      <section className="relative py-20 px-6 bg-gradient-to-b from-white to-[#FAF8F5] border-y border-[#3D3229]/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {results.map((r) => (
              <div key={r.label} className="text-center">
                <p className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-[#8B5A2B] to-[#CD853F] bg-clip-text text-transparent mb-2">
                  {r.metric}
                </p>
                <p className="text-[#3D3229] font-semibold mb-1">{r.label}</p>
                <p className="text-sm text-[#8B7355]">{r.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Features - Detailed */}
      <section id="features" className="relative py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">Core Features</p>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
              Everything you need to land the offer
            </h2>
            <p className="text-lg text-[#6B5744]">
              We built the interview prep tool we wished existed. Every feature is designed to create real interview pressure and provide actionable feedback.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {coreFeatures.map((f) => {
              const Icon = f.icon;
              return (
                <div
                  key={f.title}
                  className={`group p-8 rounded-2xl bg-white border transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#8B5A2B]/10 ${
                    f.highlight
                      ? 'border-[#8B5A2B]/30 shadow-lg shadow-[#8B5A2B]/5'
                      : 'border-[#3D3229]/10 hover:border-[#8B5A2B]/30'
                  }`}
                >
                  <div className="flex items-start gap-5">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A] flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-lg shadow-[#8B5A2B]/20">
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-3 text-[#3D3229]">{f.title}</h3>
                      <p className="text-[#6B5744] leading-relaxed">{f.desc}</p>
                    </div>
                  </div>
                  {f.highlight && (
                    <div className="mt-5 pt-5 border-t border-[#8B5A2B]/20">
                      <span className="inline-flex items-center gap-2 text-sm font-medium text-[#8B5A2B]">
                        <Sparkles className="h-4 w-4" />
                        Our most unique feature - what makes us different
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Interview Types */}
      <section className="relative py-20 px-6 bg-gradient-to-b from-[#FAF8F5] to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">Interview Types</p>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-[#3D3229]">
              Prepare for any interview format
            </h2>
            <p className="text-lg text-[#6B5744]">
              Different roles require different interview styles. We support them all.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {interviewTypes.map((type) => {
              const Icon = type.icon;
              return (
                <div
                  key={type.name}
                  className="p-5 rounded-xl bg-white border border-[#3D3229]/10 hover:border-[#8B5A2B]/30 hover:shadow-lg transition-all text-center group"
                >
                  <div className="w-12 h-12 rounded-lg bg-[#8B5A2B]/10 flex items-center justify-center mx-auto mb-3 group-hover:bg-[#8B5A2B]/20 transition-colors">
                    <Icon className="h-6 w-6 text-[#8B5A2B]" />
                  </div>
                  <h3 className="font-semibold text-[#3D3229] mb-1">{type.name}</h3>
                  <p className="text-xs text-[#8B7355]">{type.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Resume Features */}
      <section className="relative py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">Resume Intelligence</p>
              <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
                Your resume becomes your interview prep guide
              </h2>
              <p className="text-lg text-[#6B5744] mb-10">
                Upload your resume and we&apos;ll identify exactly where interviewers will probe. Know your weak points before you walk in the door.
              </p>

              <div className="space-y-6">
                {resumeFeatures.map((f) => {
                  const Icon = f.icon;
                  return (
                    <div key={f.title} className="flex gap-4">
                      <div className="w-10 h-10 rounded-lg bg-[#8B5A2B]/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="h-5 w-5 text-[#8B5A2B]" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-[#3D3229] mb-1">{f.title}</h3>
                        <p className="text-sm text-[#6B5744]">{f.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#8B5A2B]/10 to-[#D4A574]/10 rounded-3xl blur-2xl" />
              <div className="relative bg-white rounded-2xl border border-[#3D3229]/10 p-6 shadow-xl">
                <div className="flex items-center gap-3 mb-6">
                  <FileText className="h-6 w-6 text-[#8B5A2B]" />
                  <span className="font-semibold text-[#3D3229]">Resume Analysis</span>
                  <span className="ml-auto px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-medium">
                    Analyzed
                  </span>
                </div>

                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-[#6B5744]">Overall Health Score</span>
                    <span className="text-2xl font-bold text-[#8B5A2B]">78/100</span>
                  </div>
                  <div className="h-2 bg-[#FAF8F5] rounded-full overflow-hidden">
                    <div className="h-full w-[78%] bg-gradient-to-r from-[#8B5A2B] to-[#D4A574] rounded-full" />
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <div className="flex items-center gap-2 mb-1">
                      <Eye className="h-4 w-4 text-amber-600" />
                      <span className="font-medium text-amber-800 text-sm">Vulnerability Found</span>
                    </div>
                    <p className="text-xs text-amber-700">3-month employment gap in 2022 - prepare your story</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-green-800 text-sm">Strong Point</span>
                    </div>
                    <p className="text-xs text-green-700">Clear quantified impact metrics in recent roles</p>
                  </div>
                </div>

                <button className="w-full py-3 rounded-xl bg-[#8B5A2B]/10 text-[#8B5A2B] font-medium hover:bg-[#8B5A2B]/20 transition-colors text-sm">
                  Generate Practice Questions from Resume
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Company Types */}
      <section className="relative py-20 px-6 bg-gradient-to-b from-white to-[#FAF8F5]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">Company-Specific Prep</p>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-[#3D3229]">
              Tailored to your target companies
            </h2>
            <p className="text-lg text-[#6B5744]">
              Different companies interview differently. We match the style, questions, and evaluation criteria.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {companyTypes.map((company) => {
              const Icon = company.icon;
              return (
                <div
                  key={company.name}
                  className="p-5 rounded-xl bg-white border border-[#3D3229]/10 hover:border-[#8B5A2B]/30 hover:shadow-lg transition-all text-center group"
                >
                  <div className="w-12 h-12 rounded-lg bg-[#8B5A2B]/10 flex items-center justify-center mx-auto mb-3 group-hover:bg-[#8B5A2B]/20 transition-colors">
                    <Icon className="h-6 w-6 text-[#8B5A2B]" />
                  </div>
                  <h3 className="font-semibold text-[#3D3229] mb-1">{company.name}</h3>
                  <p className="text-xs text-[#8B7355]">{company.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="relative py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">How It Works</p>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
              From nervous to offer-ready in 5 steps
            </h2>
            <p className="text-lg text-[#6B5744]">
              A systematic approach to interview preparation that actually works.
            </p>
          </div>

          <div className="relative">
            {/* Connecting line */}
            <div className="hidden lg:block absolute left-[calc(50%-1px)] top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#8B5A2B]/20 via-[#8B5A2B]/40 to-[#8B5A2B]/20" />

            <div className="space-y-12 lg:space-y-0">
              {howItWorks.map((step, index) => (
                <div
                  key={step.step}
                  className={`relative lg:grid lg:grid-cols-2 lg:gap-16 items-center ${
                    index % 2 === 0 ? '' : 'lg:flex-row-reverse'
                  }`}
                >
                  <div className={index % 2 === 0 ? 'lg:text-right lg:pr-16' : 'lg:order-2 lg:pl-16'}>
                    <div className={`inline-flex items-center gap-3 mb-4 ${index % 2 === 0 ? 'lg:flex-row-reverse' : ''}`}>
                      <span className="text-5xl font-bold text-[#8B5A2B]/20">{step.step}</span>
                      <div className="hidden lg:block w-12 h-0.5 bg-[#8B5A2B]/30" />
                    </div>
                    <h3 className="text-2xl font-bold mb-3 text-[#3D3229]">{step.title}</h3>
                    <p className="text-[#6B5744] leading-relaxed">{step.desc}</p>
                  </div>

                  {/* Center dot */}
                  <div className="hidden lg:flex absolute left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#8B5A2B] border-4 border-[#FAF8F5]" />

                  <div className={`${index % 2 === 0 ? 'lg:order-2' : ''} mt-6 lg:mt-0`}>
                    {/* Empty for alternating layout */}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="relative py-24 px-6 bg-gradient-to-b from-[#FAF8F5] to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">Success Stories</p>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
              From anxious to offer-ready
            </h2>
            <p className="text-lg text-[#6B5744]">
              Real stories from people who transformed their interview performance
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div
                key={t.author}
                className="p-6 rounded-2xl bg-white border border-[#3D3229]/10 hover:border-[#8B5A2B]/30 hover:shadow-xl transition-all"
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }, (_, i) => (
                    <Star key={i} className="h-4 w-4 fill-[#D4A574] text-[#D4A574]" />
                  ))}
                </div>
                <p className="text-[#3D3229] leading-relaxed mb-6 text-sm">&ldquo;{t.quote}&rdquo;</p>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A] flex items-center justify-center font-semibold text-white">
                    {t.initials}
                  </div>
                  <div>
                    <p className="font-semibold text-[#3D3229]">{t.author}</p>
                    <p className="text-sm text-[#8B7355]">{t.role}</p>
                  </div>
                </div>
                <div className="pt-4 border-t border-[#3D3229]/10">
                  <span className="inline-flex items-center gap-2 text-xs font-medium text-[#8B5A2B]">
                    <Award className="h-3 w-3" />
                    {t.result}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="relative py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">Pricing</p>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
              Invest in your career
            </h2>
            <p className="text-lg text-[#6B5744]">
              Start free, upgrade when you&apos;re ready to get serious. Cancel anytime.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {pricing.map((p) => (
              <div
                key={p.name}
                className={`relative p-8 rounded-2xl transition-all ${
                  p.highlight
                    ? 'bg-gradient-to-b from-[#8B5A2B]/10 to-white border-2 border-[#8B5A2B]/50 shadow-xl shadow-[#8B5A2B]/10 lg:scale-105'
                    : 'bg-white border border-[#3D3229]/10 hover:border-[#8B5A2B]/30'
                }`}
              >
                {p.highlight && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="px-4 py-1.5 rounded-full bg-gradient-to-r from-[#8B5A2B] to-[#5D3A1A] text-white text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-1 text-[#3D3229]">{p.name}</h3>
                  <p className="text-sm text-[#8B7355]">{p.desc}</p>
                </div>
                <div className="mb-6">
                  <span className="text-5xl font-bold text-[#3D3229]">${p.price}</span>
                  <span className="text-[#8B7355] ml-2">{p.period}</span>
                </div>
                <ul className="space-y-3 mb-6">
                  {p.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <CheckCircle2 className={`h-5 w-5 flex-shrink-0 mt-0.5 ${p.highlight ? 'text-[#8B5A2B]' : 'text-[#A0522D]'}`} />
                      <span className="text-[#3D3229] text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                {p.limitations.length > 0 && (
                  <ul className="space-y-2 mb-6 pt-4 border-t border-[#3D3229]/10">
                    {p.limitations.map((limitation) => (
                      <li key={limitation} className="flex items-start gap-3 text-sm text-[#8B7355]">
                        <span className="text-[#C4956A]">-</span>
                        {limitation}
                      </li>
                    ))}
                  </ul>
                )}
                <Link
                  href="/register"
                  className={`block w-full py-3.5 rounded-xl text-center font-semibold transition-all ${
                    p.highlight
                      ? 'bg-gradient-to-r from-[#8B5A2B] to-[#5D3A1A] text-white hover:from-[#9A6B3C] hover:to-[#6B4420] shadow-lg shadow-[#8B5A2B]/20'
                      : 'bg-[#FAF8F5] text-[#3D3229] hover:bg-[#8B5A2B]/10 border border-[#3D3229]/10'
                  }`}
                >
                  {p.cta}
                </Link>
              </div>
            ))}
          </div>

          <p className="text-center text-[#8B7355] text-sm mt-8">
            All plans include a 7-day money-back guarantee. No questions asked.
          </p>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="relative py-24 px-6 bg-gradient-to-b from-[#FAF8F5] to-white">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-[#8B5A2B] font-semibold tracking-widest text-sm mb-4 uppercase">FAQ</p>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
              Common questions
            </h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-white border border-[#3D3229]/10 hover:border-[#8B5A2B]/30 transition-all"
              >
                <h3 className="font-semibold text-[#3D3229] mb-3">{faq.q}</h3>
                <p className="text-[#6B5744] leading-relaxed text-sm">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[#8B5A2B]/15 to-[#D4A574]/15 rounded-3xl blur-3xl" />
            <div className="relative p-12 lg:p-20 rounded-3xl bg-white border border-[#3D3229]/10 text-center shadow-xl">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A] mb-8 shadow-xl shadow-[#8B5A2B]/25">
                <Flame className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[#3D3229]">
                Ready to transform your interviews?
              </h2>
              <p className="text-xl text-[#6B5744] mb-10 max-w-2xl mx-auto">
                Join thousands of professionals who went from nervous to confident, from rejected to hired.
                Start free and see the difference in your first session.
              </p>
              <Link
                href="/register"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#8B5A2B] to-[#5D3A1A] text-white text-lg font-semibold hover:from-[#9A6B3C] hover:to-[#6B4420] transition-all shadow-xl shadow-[#8B5A2B]/25 hover:shadow-[#8B5A2B]/40"
              >
                Start Your Free Trial
                <ArrowRight className="h-5 w-5" />
              </Link>
              <p className="text-[#8B7355] text-sm mt-6">No credit card required • 5 free interviews • Cancel anytime</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-12 px-6 border-t border-[#3D3229]/10 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-gradient-to-br from-[#8B5A2B] to-[#5D3A1A]">
                  <Flame className="h-4 w-4 text-white" />
                </div>
                <span className="font-semibold text-[#3D3229]">UnderFireAI</span>
              </div>
              <p className="text-sm text-[#8B7355]">
                AI-powered interview coaching that actually prepares you for real pressure.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-[#3D3229] mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-[#6B5744]">
                <li><Link href="#features" className="hover:text-[#8B5A2B] transition-colors">Features</Link></li>
                <li><Link href="#pricing" className="hover:text-[#8B5A2B] transition-colors">Pricing</Link></li>
                <li><Link href="#faq" className="hover:text-[#8B5A2B] transition-colors">FAQ</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3D3229] mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-[#6B5744]">
                <li><Link href="#" className="hover:text-[#8B5A2B] transition-colors">About</Link></li>
                <li><Link href="#" className="hover:text-[#8B5A2B] transition-colors">Blog</Link></li>
                <li><Link href="#" className="hover:text-[#8B5A2B] transition-colors">Careers</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-[#3D3229] mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-[#6B5744]">
                <li><Link href="#" className="hover:text-[#8B5A2B] transition-colors">Privacy Policy</Link></li>
                <li><Link href="#" className="hover:text-[#8B5A2B] transition-colors">Terms of Service</Link></li>
                <li><Link href="#" className="hover:text-[#8B5A2B] transition-colors">Contact</Link></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-[#3D3229]/10 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-[#8B7355]">© 2025 UnderFireAI. All rights reserved.</p>
            <div className="flex items-center gap-6 text-sm text-[#6B5744]">
              <Link href="#" className="hover:text-[#8B5A2B] transition-colors">Twitter</Link>
              <Link href="#" className="hover:text-[#8B5A2B] transition-colors">LinkedIn</Link>
              <Link href="#" className="hover:text-[#8B5A2B] transition-colors">GitHub</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
