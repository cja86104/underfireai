'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { motion, useScroll, useTransform, useInView, useMotionValue, useSpring } from 'framer-motion';
import {
  Flame,
  MessageSquare,
  Brain,
  Target,
  TrendingUp,
  Mic,
  Shield,
  Sparkles,
  ChevronRight,
  Play,
  Star,
  CheckCircle2,
  ArrowRight,
  Zap,
  Users,
  Award,
  Clock,
  BarChart3,
  Headphones,
  Eye,
  Lock,
} from 'lucide-react';

// Animated counter hook
function useCounter(end: number, duration: number = 2000) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;
    
    let startTime: number;
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  }, [end, duration, isInView]);

  return { count, ref };
}

// Floating animation variants
const floatVariants = {
  animate: {
    y: [-10, 10, -10],
    transition: {
      duration: 6,
      repeat: Infinity,
      ease: 'easeInOut',
    },
  },
};

// Stagger container
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

// Fade up item
const fadeUpItem = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: [0.4, 0, 0.2, 1],
    },
  },
};

// Scale in item
const scaleInItem = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: [0.4, 0, 0.2, 1],
    },
  },
};

export default function LandingPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  // Parallax transforms
  const heroY = useTransform(scrollYProgress, [0, 0.3], [0, -100]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const floatingCardsY = useTransform(scrollYProgress, [0, 0.5], [0, -200]);
  
  // Smooth mouse position
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const smoothMouseX = useSpring(mouseX, { damping: 50, stiffness: 400 });
  const smoothMouseY = useSpring(mouseY, { damping: 50, stiffness: 400 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      mouseX.set((clientX / innerWidth - 0.5) * 20);
      mouseY.set((clientY / innerHeight - 0.5) * 20);
      setMousePosition({ x: clientX, y: clientY });
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  // Stats counters
  const stats = [
    { value: 50000, suffix: '+', label: 'Interviews Completed', icon: MessageSquare },
    { value: 94, suffix: '%', label: 'Success Rate', icon: Target },
    { value: 10000, suffix: '+', label: 'Users Trained', icon: Users },
    { value: 4.9, suffix: '', label: 'Average Rating', icon: Star, decimals: 1 },
  ];

  const features = [
    {
      icon: Brain,
      title: 'Hidden Personalities',
      description: 'Each AI interviewer has unique traits, biases, and preferences you must discover through interaction.',
      color: 'from-purple-500 to-violet-600',
    },
    {
      icon: Target,
      title: 'STAR Detection',
      description: 'Real-time analysis of your responses with instant feedback on structure and impact.',
      color: 'from-orange-500 to-amber-600',
    },
    {
      icon: Mic,
      title: 'Voice Mode',
      description: 'Practice speaking your answers naturally with realistic voice conversations.',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      icon: BarChart3,
      title: 'Deep Analytics',
      description: 'Track your progress with detailed metrics on clarity, confidence, and technical depth.',
      color: 'from-emerald-500 to-green-600',
    },
    {
      icon: Shield,
      title: 'Company Profiles',
      description: 'Practice for FAANG, startups, consulting firms, and more with tailored interview styles.',
      color: 'from-rose-500 to-pink-600',
    },
    {
      icon: Zap,
      title: 'Adaptive Difficulty',
      description: 'Interviews adjust in real-time based on your performance and responses.',
      color: 'from-yellow-500 to-orange-600',
    },
  ];

  const testimonials = [
    {
      quote: "After 2 weeks of practice, I landed my dream job at Google. The hidden personality feature made me so much better at reading interviewers.",
      author: "Sarah Chen",
      role: "Software Engineer at Google",
      avatar: "SC",
    },
    {
      quote: "The AI feedback is incredibly detailed. It caught things I never noticed about my communication style.",
      author: "Marcus Johnson",
      role: "Product Manager at Meta",
      avatar: "MJ",
    },
    {
      quote: "Voice mode was a game-changer. Practicing out loud helped me overcome my nervousness completely.",
      author: "Priya Patel",
      role: "Data Scientist at Netflix",
      avatar: "PP",
    },
  ];

  const pricingPlans = [
    {
      name: 'Free',
      price: '$0',
      description: 'Perfect for getting started',
      features: ['3 interviews/month', 'Basic feedback', 'Text mode only', 'Core analytics'],
      cta: 'Start Free',
      popular: false,
    },
    {
      name: 'Pro',
      price: '$19',
      description: 'For serious preparation',
      features: ['Unlimited interviews', 'Voice mode', 'Full analytics', 'Priority support', 'All interviewer types', 'Resume integration'],
      cta: 'Go Pro',
      popular: true,
    },
    {
      name: 'Premium',
      price: '$39',
      description: 'Maximum advantage',
      features: ['Everything in Pro', 'Resume coaching', 'Company deep-dives', '1-on-1 strategy session', 'Interview recordings', 'Custom scenarios'],
      cta: 'Go Premium',
      popular: false,
    },
  ];

  return (
    <div ref={containerRef} className="relative min-h-screen overflow-hidden">
      {/* Animated Background */}
      <div className="gradient-bg">
        <div className="gradient-orb gradient-orb-1" />
        <div className="gradient-orb gradient-orb-2" />
        <div className="gradient-orb gradient-orb-3" />
        <div className="gradient-orb gradient-orb-4" />
      </div>
      <div className="grid-pattern fixed inset-0 pointer-events-none" />
      <div className="noise-overlay" />

      {/* Floating Navigation */}
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
        className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-4xl px-4"
      >
        <div className="glass rounded-2xl px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <motion.div
              whileHover={{ rotate: 180, scale: 1.1 }}
              transition={{ duration: 0.3 }}
              className="p-2 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500"
            >
              <Flame className="h-5 w-5 text-white" />
            </motion.div>
            <span className="font-bold text-lg text-white">UnderFireAI</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <NavLink href="#features">Features</NavLink>
            <NavLink href="#testimonials">Testimonials</NavLink>
            <NavLink href="#pricing">Pricing</NavLink>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm font-medium text-slate-300 hover:text-white transition-colors"
            >
              Sign In
            </Link>
            <Link href="/register">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-primary !px-5 !py-2.5 text-sm !rounded-xl"
              >
                Get Started
              </motion.button>
            </Link>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-32 pb-20 px-4">
        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 text-center max-w-5xl mx-auto"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-light mb-8"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500" />
            </span>
            <span className="text-sm text-slate-300">Powered by advanced AI</span>
            <Sparkles className="h-4 w-4 text-orange-400" />
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="hero-title font-bold text-white mb-6"
          >
            Interview Practice
            <br />
            <span className="gradient-text-animated">Under Fire</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto mb-10 text-balance"
          >
            AI interviewers with hidden personalities. Discover their style, 
            adapt your answers, and master any interview.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
          >
            <Link href="/register">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-primary text-lg flex items-center gap-2 glow-orange"
              >
                Start Free Trial
                <ArrowRight className="h-5 w-5" />
              </motion.button>
            </Link>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-secondary text-lg flex items-center gap-2"
            >
              <Play className="h-5 w-5" />
              Watch Demo
            </motion.button>
          </motion.div>

          {/* Floating Interview Cards */}
          <motion.div
            style={{ y: floatingCardsY }}
            className="relative h-[400px] md:h-[500px]"
          >
            {/* Main Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotateX: 20 }}
              animate={{ opacity: 1, scale: 1, rotateX: 0 }}
              transition={{ duration: 1, delay: 0.6 }}
              style={{ x: smoothMouseX, y: smoothMouseY }}
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg"
            >
              <div className="glass-card rounded-3xl p-6 card-shine">
                <div className="flex items-center gap-4 mb-4">
                  <div className="relative">
                    <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center text-white text-xl font-bold">
                      JK
                    </div>
                    <span className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full bg-green-500 border-2 border-slate-900" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold text-white text-lg">Jordan Kim</h3>
                    <p className="text-sm text-slate-400">Senior Engineering Manager</p>
                  </div>
                  <div className="ml-auto flex items-center gap-1 text-amber-400">
                    <Eye className="h-4 w-4" />
                    <span className="text-xs font-medium">Hidden</span>
                  </div>
                </div>
                
                <div className="glass-light rounded-2xl p-4 mb-4">
                  <p className="text-slate-300 text-left">
                    "Tell me about a time when you had to make a difficult technical decision with incomplete information."
                  </p>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2 text-slate-400">
                    <Clock className="h-4 w-4" />
                    <span>12:34</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 text-emerald-400">
                      <TrendingUp className="h-4 w-4" />
                      87%
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Floating Side Cards */}
            <motion.div
              variants={floatVariants}
              animate="animate"
              className="absolute left-0 top-1/4 hidden lg:block"
            >
              <div className="glass-card rounded-2xl p-4 w-64 card-shine">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center">
                    <Brain className="h-5 w-5 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-white text-sm">STAR Analysis</p>
                    <p className="text-xs text-slate-400">Real-time</p>
                  </div>
                </div>
                <div className="space-y-2">
                  {['Situation', 'Task', 'Action', 'Result'].map((item, i) => (
                    <div key={item} className="flex items-center gap-2">
                      <CheckCircle2 className={`h-4 w-4 ${i < 3 ? 'text-emerald-400' : 'text-slate-600'}`} />
                      <span className={`text-sm ${i < 3 ? 'text-slate-300' : 'text-slate-500'}`}>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={floatVariants}
              animate="animate"
              style={{ animationDelay: '-3s' }}
              className="absolute right-0 top-1/3 hidden lg:block"
            >
              <div className="glass-card rounded-2xl p-4 w-56 card-shine">
                <div className="flex items-center gap-2 mb-3">
                  <Mic className="h-5 w-5 text-cyan-400" />
                  <span className="font-medium text-white text-sm">Voice Mode</span>
                </div>
                <div className="flex items-center gap-2">
                  {[...Array(12)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{ scaleY: [1, 2, 1] }}
                      transition={{
                        duration: 0.5,
                        repeat: Infinity,
                        delay: i * 0.1,
                      }}
                      className="w-1 h-4 bg-gradient-to-t from-cyan-500 to-blue-400 rounded-full"
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="flex flex-col items-center gap-2 text-slate-500"
          >
            <span className="text-xs uppercase tracking-wider">Scroll</span>
            <div className="w-5 h-8 rounded-full border-2 border-slate-600 flex justify-center pt-2">
              <motion.div
                animate={{ y: [0, 8, 0], opacity: [1, 0, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-1 h-1 rounded-full bg-orange-500"
              />
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
          >
            {stats.map((stat, index) => {
              const { count, ref } = useCounter(
                stat.decimals ? stat.value * 10 : stat.value,
                2000
              );
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  variants={scaleInItem}
                  className="glass-card glass-card-hover rounded-3xl p-6 text-center spotlight"
                >
                  <div className="inline-flex items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500/20 to-amber-500/20 p-3 mb-4">
                    <Icon className="h-6 w-6 text-orange-400" />
                  </div>
                  <p className="text-4xl md:text-5xl font-bold text-white mb-2 counter">
                    <span ref={ref}>
                      {stat.decimals ? (count / 10).toFixed(1) : count.toLocaleString()}
                    </span>
                    {stat.suffix}
                  </p>
                  <p className="text-slate-400 text-sm">{stat.label}</p>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="text-center mb-20"
          >
            <motion.span
              variants={fadeUpItem}
              className="inline-block px-4 py-2 rounded-full glass-light text-sm text-orange-400 mb-6"
            >
              Features
            </motion.span>
            <motion.h2
              variants={fadeUpItem}
              className="section-title font-bold text-white mb-6"
            >
              Everything You Need to
              <br />
              <span className="gradient-text">Ace Your Interview</span>
            </motion.h2>
            <motion.p
              variants={fadeUpItem}
              className="text-xl text-slate-400 max-w-2xl mx-auto"
            >
              Advanced AI technology meets proven interview coaching methodology
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  variants={fadeUpItem}
                  className="group"
                >
                  <div className="glass-card glass-card-hover rounded-3xl p-8 h-full card-shine spotlight">
                    <div className={`inline-flex items-center justify-center rounded-2xl bg-gradient-to-br ${feature.color} p-4 mb-6 feature-icon-bg`}>
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                    <p className="text-slate-400 leading-relaxed">{feature.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="text-center mb-20"
          >
            <motion.span
              variants={fadeUpItem}
              className="inline-block px-4 py-2 rounded-full glass-light text-sm text-orange-400 mb-6"
            >
              How It Works
            </motion.span>
            <motion.h2
              variants={fadeUpItem}
              className="section-title font-bold text-white mb-6"
            >
              Three Steps to
              <br />
              <span className="gradient-text">Interview Mastery</span>
            </motion.h2>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {[
              {
                step: '01',
                title: 'Choose Your Challenge',
                description: 'Select interview type, company style, and difficulty. Each interviewer is generated with unique hidden traits.',
                icon: Target,
              },
              {
                step: '02',
                title: 'Practice Under Pressure',
                description: 'Answer questions in real-time while the AI adapts to your responses and reveals its personality.',
                icon: MessageSquare,
              },
              {
                step: '03',
                title: 'Master & Improve',
                description: 'Get detailed feedback, track your progress, and learn what makes interviewers tick.',
                icon: TrendingUp,
              },
            ].map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.step}
                  variants={fadeUpItem}
                  className="relative"
                >
                  {index < 2 && (
                    <div className="hidden md:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-orange-500/50 to-transparent z-0" />
                  )}
                  <div className="glass-card rounded-3xl p-8 relative z-10 h-full">
                    <span className="text-6xl font-bold text-orange-500/20 absolute top-4 right-6">
                      {item.step}
                    </span>
                    <div className="inline-flex items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 p-4 mb-6">
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-3">{item.title}</h3>
                    <p className="text-slate-400 leading-relaxed">{item.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="text-center mb-20"
          >
            <motion.span
              variants={fadeUpItem}
              className="inline-block px-4 py-2 rounded-full glass-light text-sm text-orange-400 mb-6"
            >
              Success Stories
            </motion.span>
            <motion.h2
              variants={fadeUpItem}
              className="section-title font-bold text-white mb-6"
            >
              Trusted by
              <br />
              <span className="gradient-text">Top Performers</span>
            </motion.h2>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-6"
          >
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.author}
                variants={fadeUpItem}
              >
                <div className="glass-card rounded-3xl p-8 h-full testimonial-card">
                  <div className="flex gap-1 mb-6">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="text-slate-300 leading-relaxed mb-8">"{testimonial.quote}"</p>
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center text-white font-semibold">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-white">{testimonial.author}</p>
                      <p className="text-sm text-slate-400">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="text-center mb-20"
          >
            <motion.span
              variants={fadeUpItem}
              className="inline-block px-4 py-2 rounded-full glass-light text-sm text-orange-400 mb-6"
            >
              Pricing
            </motion.span>
            <motion.h2
              variants={fadeUpItem}
              className="section-title font-bold text-white mb-6"
            >
              Simple, Transparent
              <br />
              <span className="gradient-text">Pricing</span>
            </motion.h2>
            <motion.p
              variants={fadeUpItem}
              className="text-xl text-slate-400 max-w-2xl mx-auto"
            >
              Start free, upgrade when you&apos;re ready
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-6"
          >
            {pricingPlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                variants={scaleInItem}
                className={plan.popular ? 'md:-mt-4 md:mb-4' : ''}
              >
                <div className={`glass-card rounded-3xl p-8 h-full relative ${plan.popular ? 'pricing-popular' : ''}`}>
                  {plan.popular && (
                    <span className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-orange-500 to-amber-500 text-white text-sm font-semibold">
                      Most Popular
                    </span>
                  )}
                  <div className="text-center mb-8">
                    <h3 className="text-xl font-semibold text-white mb-2">{plan.name}</h3>
                    <p className="text-slate-400 text-sm mb-4">{plan.description}</p>
                    <p className="text-5xl font-bold text-white">
                      {plan.price}
                      <span className="text-lg font-normal text-slate-400">/mo</span>
                    </p>
                  </div>
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3">
                        <CheckCircle2 className="h-5 w-5 text-emerald-400 flex-shrink-0" />
                        <span className="text-slate-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/register" className="block">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className={`w-full py-4 rounded-2xl font-semibold transition-all ${
                        plan.popular
                          ? 'btn-primary !rounded-2xl'
                          : 'btn-secondary !rounded-2xl'
                      }`}
                    >
                      {plan.cta}
                    </motion.button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="glass-card rounded-[2.5rem] p-12 md:p-16 text-center relative overflow-hidden"
          >
            {/* Background glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 via-transparent to-purple-500/10" />
            
            <div className="relative z-10">
              <motion.div
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="inline-flex items-center justify-center rounded-3xl bg-gradient-to-br from-orange-500 to-amber-500 p-5 mb-8 glow-orange"
              >
                <Flame className="h-10 w-10 text-white" />
              </motion.div>
              
              <h2 className="section-title font-bold text-white mb-6">
                Ready to Conquer
                <br />
                <span className="gradient-text">Your Next Interview?</span>
              </h2>
              
              <p className="text-xl text-slate-400 max-w-xl mx-auto mb-10">
                Join thousands of professionals who transformed their interview skills with UnderFireAI.
              </p>
              
              <Link href="/register">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-primary text-lg glow-orange inline-flex items-center gap-2"
                >
                  Start Your Free Trial
                  <ArrowRight className="h-5 w-5" />
                </motion.button>
              </Link>
              
              <p className="text-slate-500 text-sm mt-6">No credit card required • Cancel anytime</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-12 px-4 border-t border-slate-800/50">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500">
                <Flame className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-lg text-white">UnderFireAI</span>
            </div>
            
            <div className="flex items-center gap-8 text-sm text-slate-400">
              <Link href="#" className="hover:text-white transition-colors">Privacy</Link>
              <Link href="#" className="hover:text-white transition-colors">Terms</Link>
              <Link href="#" className="hover:text-white transition-colors">Support</Link>
            </div>
            
            <p className="text-sm text-slate-500">
              © 2024 UnderFireAI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Navigation Link Component
function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="text-sm font-medium text-slate-400 hover:text-white transition-colors"
    >
      {children}
    </Link>
  );
}
