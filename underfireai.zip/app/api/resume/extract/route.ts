import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { getCurrentUser } from '@/lib/supabase/server';
import { createChatCompletion } from '@/lib/ai/chat-client';
import { AI_MODELS, MODEL_PARAMS } from '@/lib/ai/config';
import type { ParsedResumeData, Json } from '@/types/database';

interface ExtractRequest {
  resumeText: string;
  resumeId?: string;
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized', message: 'Please sign in to continue' },
        { status: 401 }
      );
    }

    const body: ExtractRequest = await request.json();
    const { resumeText, resumeId } = body;

    if (!resumeText || resumeText.trim().length < 50) {
      return NextResponse.json(
        { error: 'Validation error', message: 'Resume text is required (minimum 50 characters)' },
        { status: 400 }
      );
    }

    // Extract structured data using AI
    const extractionPrompt = `Extract structured information from this resume. Return ONLY valid JSON.

RESUME TEXT:
${resumeText.slice(0, 8000)}

Extract and return this JSON structure:
{
  "name": "Full name",
  "email": "Email address or null",
  "phone": "Phone number or null",
  "location": "City, State/Country or null",
  "summary": "Professional summary (2-3 sentences) or null",
  "experience": [
    {
      "company": "Company name",
      "title": "Job title",
      "start_date": "Start date (YYYY-MM format)",
      "end_date": "End date or null if current",
      "description": "Brief role description",
      "highlights": ["Key achievement 1", "Key achievement 2"]
    }
  ],
  "education": [
    {
      "institution": "School name",
      "degree": "Degree type",
      "field": "Field of study",
      "graduation_date": "Graduation year"
    }
  ],
  "skills": ["skill1", "skill2", "skill3"],
  "certifications": ["certification1", "certification2"]
}

Be thorough in extracting skills - include technical skills, soft skills, tools, languages, and frameworks mentioned.
Return ONLY the JSON, no additional text.`;

    const completion = await createChatCompletion(
      [
        { role: 'system', content: 'You extract structured data from resumes. Return only valid JSON with no markdown formatting.' },
        { role: 'user', content: extractionPrompt },
      ],
      {
        model: AI_MODELS.RESUME_PARSE,
        ...MODEL_PARAMS.resumeParse,
      }
    );

    let content = completion.choices[0]?.message?.content || '{}';
    content = content.replace(/^```(?:json)?\s*\n?/i, '').replace(/\n?\s*```\s*$/i, '');

    let parsedData: ParsedResumeData;

    try {
      const raw = JSON.parse(content);

      parsedData = {
        name: typeof raw.name === 'string' ? raw.name : undefined,
        email: typeof raw.email === 'string' ? raw.email : undefined,
        phone: typeof raw.phone === 'string' ? raw.phone : undefined,
        location: typeof raw.location === 'string' ? raw.location : undefined,
        summary: typeof raw.summary === 'string' ? raw.summary : undefined,
        experience: Array.isArray(raw.experience)
          ? raw.experience.map((exp: Record<string, unknown>) => ({
              company: String(exp.company || ''),
              title: String(exp.title || ''),
              start_date: String(exp.start_date || ''),
              end_date: exp.end_date ? String(exp.end_date) : null,
              description: String(exp.description || ''),
              highlights: Array.isArray(exp.highlights)
                ? exp.highlights.filter((h: unknown) => typeof h === 'string')
                : [],
            }))
          : [],
        education: Array.isArray(raw.education)
          ? raw.education.map((edu: Record<string, unknown>) => ({
              institution: String(edu.institution || ''),
              degree: String(edu.degree || ''),
              field: String(edu.field || ''),
              graduation_date: String(edu.graduation_date || ''),
            }))
          : [],
        skills: Array.isArray(raw.skills)
          ? raw.skills.filter((s: unknown) => typeof s === 'string')
          : [],
        certifications: Array.isArray(raw.certifications)
          ? raw.certifications.filter((c: unknown) => typeof c === 'string')
          : undefined,
      };
    } catch (parseError) {
      console.error('Error parsing AI response:', parseError);
      return NextResponse.json(
        { error: 'Parse error', message: 'Failed to parse resume data' },
        { status: 500 }
      );
    }

    // Calculate experience years
    let experienceYears = 0;
    for (const exp of parsedData.experience) {
      const start = new Date(exp.start_date);
      const end = exp.end_date ? new Date(exp.end_date) : new Date();
      if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
        experienceYears += (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24 * 365);
      }
    }
    experienceYears = Math.round(experienceYears * 10) / 10;

    // If resumeId provided, update the resume record
    if (resumeId) {
      const supabase = await createClient();

      const { error: updateError } = await supabase
        .from('user_resumes')
        .update({
          parsed_data: parsedData as unknown as Json,
          skills: parsedData.skills,
          experience_years: Math.round(experienceYears),
        })
        .eq('id', resumeId)
        .eq('user_id', user.id);

      if (updateError) {
        console.error('Error updating resume:', updateError);
      }
    }

    // Generate skill categories
    const skillCategories = categorizeSkills(parsedData.skills);

    // Generate interview talking points
    const talkingPoints = generateTalkingPoints(parsedData);

    return NextResponse.json({
      success: true,
      data: parsedData,
      experienceYears,
      skillCategories,
      talkingPoints,
      resumeId: resumeId || null,
    });

  } catch (error) {
    console.error('Error extracting resume data:', error);
    return NextResponse.json(
      { error: 'Server error', message: 'Failed to extract resume data' },
      { status: 500 }
    );
  }
}

function categorizeSkills(skills: string[]): Record<string, string[]> {
  const categories: Record<string, string[]> = {
    programming: [],
    frameworks: [],
    databases: [],
    cloud: [],
    tools: [],
    soft_skills: [],
    other: [],
  };

  const patterns: Record<string, RegExp> = {
    programming: /^(javascript|typescript|python|java|c\+\+|c#|go|rust|ruby|php|swift|kotlin|scala|r|matlab|sql|html|css|bash|shell)$/i,
    frameworks: /^(react|angular|vue|next\.?js|node\.?js|express|django|flask|spring|rails|laravel|\.net|tensorflow|pytorch|keras)$/i,
    databases: /^(mysql|postgresql|mongodb|redis|elasticsearch|dynamodb|cassandra|oracle|sql server|sqlite|firebase)$/i,
    cloud: /^(aws|azure|gcp|google cloud|heroku|vercel|netlify|docker|kubernetes|terraform|jenkins|ci\/cd)$/i,
    tools: /^(git|github|gitlab|jira|confluence|figma|sketch|postman|webpack|npm|yarn|maven|gradle)$/i,
    soft_skills: /^(leadership|communication|teamwork|problem.solving|project management|agile|scrum|mentoring|presentation)$/i,
  };

  for (const skill of skills) {
    let categorized = false;
    for (const [category, pattern] of Object.entries(patterns)) {
      if (pattern.test(skill)) {
        categories[category].push(skill);
        categorized = true;
        break;
      }
    }
    if (!categorized) {
      categories.other.push(skill);
    }
  }

  // Remove empty categories
  return Object.fromEntries(
    Object.entries(categories).filter(([_, skills]) => skills.length > 0)
  );
}

function generateTalkingPoints(data: ParsedResumeData): string[] {
  const points: string[] = [];

  // Most recent role
  if (data.experience.length > 0) {
    const recent = data.experience[0];
    points.push(`Current/Recent role: ${recent.title} at ${recent.company}`);
    if (recent.highlights.length > 0) {
      points.push(`Key achievement: ${recent.highlights[0]}`);
    }
  }

  // Education
  if (data.education.length > 0) {
    const edu = data.education[0];
    points.push(`Education: ${edu.degree} in ${edu.field} from ${edu.institution}`);
  }

  // Top skills
  if (data.skills.length > 0) {
    points.push(`Top skills: ${data.skills.slice(0, 5).join(', ')}`);
  }

  // Career progression
  if (data.experience.length >= 2) {
    const titles = data.experience.map(e => e.title).slice(0, 3);
    points.push(`Career path: ${titles.reverse().join(' → ')}`);
  }

  return points;
}
