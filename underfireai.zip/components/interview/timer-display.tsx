'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Loader2,
  AlertCircle,
  Square,
  RotateCcw,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils/cn';
import type { VoiceConfig } from '@/types/database';

interface VoiceModeProps {
  sessionId: string;
  isActive: boolean;
  isLoading: boolean;
  voiceConfig: VoiceConfig | null;
  onTranscript: (transcript: string) => void;
  onSpeakText: (text: string) => Promise<void>;
  lastInterviewerMessage: string | null;
}

type RecordingState = 'idle' | 'listening' | 'processing';
type PlaybackState = 'idle' | 'loading' | 'playing';

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

export function VoiceMode({
  sessionId,
  isActive,
  isLoading,
  voiceConfig,
  onTranscript,
  onSpeakText,
  lastInterviewerMessage,
}: VoiceModeProps) {
  const [recordingState, setRecordingState] = useState<RecordingState>('idle');
  const [playbackState, setPlaybackState] = useState<PlaybackState>('idle');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Check browser support on mount
  useEffect(() => {
    const SpeechRecognitionAPI =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      setIsSupported(false);
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setRecordingState('listening');
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript;
        } else {
          interim += transcript;
        }
      }

      setInterimTranscript(interim);
      if (final) {
        setFinalTranscript((prev) => prev + final);
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);

      if (event.error === 'not-allowed') {
        toast.error('Microphone access denied. Please allow microphone access in your browser settings.');
      } else if (event.error === 'no-speech') {
        // This is common, don't show error
        setRecordingState('idle');
      } else if (event.error !== 'aborted') {
        toast.error('Speech recognition error. Please try again.');
      }

      setRecordingState('idle');
    };

    recognition.onend = () => {
      if (recordingState === 'listening') {
        setRecordingState('idle');
      }
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  // Auto-play interviewer messages
  useEffect(() => {
    if (lastInterviewerMessage && !isMuted && isActive && playbackState === 'idle') {
      playInterviewerMessage(lastInterviewerMessage);
    }
  }, [lastInterviewerMessage, isMuted, isActive]);

  // Start audio level monitoring
  const startAudioLevelMonitoring = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;

      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);

      const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);

      const updateLevel = () => {
        if (analyserRef.current && recordingState === 'listening') {
          analyserRef.current.getByteFrequencyData(dataArray);
          const average = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
          setAudioLevel(average / 255);
          animationFrameRef.current = requestAnimationFrame(updateLevel);
        }
      };

      updateLevel();
    } catch (error) {
      console.error('Failed to access microphone:', error);
    }
  }, [recordingState]);

  // Stop audio level monitoring
  const stopAudioLevelMonitoring = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setAudioLevel(0);
  }, []);

  const startRecording = useCallback(async () => {
    if (!recognitionRef.current || recordingState !== 'idle' || isLoading) return;

    // Stop any playing audio
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setPlaybackState('idle');

    // Clear previous transcript
    setFinalTranscript('');
    setInterimTranscript('');

    try {
      recognitionRef.current.start();
      await startAudioLevelMonitoring();
    } catch (error) {
      console.error('Failed to start recording:', error);
      toast.error('Failed to start recording. Please try again.');
    }
  }, [recordingState, isLoading, startAudioLevelMonitoring]);

  const stopRecording = useCallback(() => {
    if (!recognitionRef.current || recordingState !== 'listening') return;

    recognitionRef.current.stop();
    stopAudioLevelMonitoring();
    setRecordingState('processing');

    // Small delay to allow final results to come in
    setTimeout(() => {
      const transcript = finalTranscript + interimTranscript;
      if (transcript.trim()) {
        onTranscript(transcript.trim());
      }
      setRecordingState('idle');
      setInterimTranscript('');
      setFinalTranscript('');
    }, 300);
  }, [recordingState, finalTranscript, interimTranscript, onTranscript, stopAudioLevelMonitoring]);

  const cancelRecording = useCallback(() => {
    if (!recognitionRef.current) return;

    recognitionRef.current.abort();
    stopAudioLevelMonitoring();
    setRecordingState('idle');
    setInterimTranscript('');
    setFinalTranscript('');
  }, [stopAudioLevelMonitoring]);

  const playInterviewerMessage = useCallback(async (text: string) => {
    if (!text || isMuted) return;

    setPlaybackState('loading');

    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voice: voiceConfig?.voice_id || 'alloy',
          speed: voiceConfig?.speed || 1.0,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'TTS request failed');
      }

      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);

      if (audioRef.current) {
        audioRef.current.src = audioUrl;
        audioRef.current.onended = () => {
          setPlaybackState('idle');
          URL.revokeObjectURL(audioUrl);
        };
        audioRef.current.onerror = () => {
          setPlaybackState('idle');
          URL.revokeObjectURL(audioUrl);
        };
        await audioRef.current.play();
        setPlaybackState('playing');
      }
    } catch (error) {
      console.error('TTS error:', error);
      setPlaybackState('idle');
      // Don't show toast for TTS errors to avoid interrupting flow
    }
  }, [voiceConfig, isMuted]);

  const stopPlayback = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setPlaybackState('idle');
  }, []);

  const toggleMute = useCallback(() => {
    if (!isMuted) {
      stopPlayback();
    }
    setIsMuted(!isMuted);
  }, [isMuted, stopPlayback]);

  if (!isSupported) {
    return (
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4">
        <div className="flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0" />
          <div>
            <p className="font-medium text-amber-400">Voice mode not supported</p>
            <p className="text-sm text-amber-400/70 mt-1">
              Your browser doesn&apos;t support speech recognition. Please use Chrome, Edge, or Safari for voice interviews.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!isActive) {
    return null;
  }

  const currentTranscript = finalTranscript + interimTranscript;

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
      {/* Hidden audio element for TTS playback */}
      <audio ref={audioRef} className="hidden" />

      {/* Status Bar */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div
            className={cn(
              'h-2 w-2 rounded-full',
              recordingState === 'listening' && 'bg-red-500 animate-pulse',
              recordingState === 'processing' && 'bg-amber-500 animate-pulse',
              recordingState === 'idle' && playbackState === 'playing' && 'bg-green-500 animate-pulse',
              recordingState === 'idle' && playbackState !== 'playing' && 'bg-slate-500'
            )}
          />
          <span className="text-sm text-slate-400">
            {recordingState === 'listening' && 'Listening...'}
            {recordingState === 'processing' && 'Processing...'}
            {recordingState === 'idle' && playbackState === 'loading' && 'Loading audio...'}
            {recordingState === 'idle' && playbackState === 'playing' && 'Interviewer speaking...'}
            {recordingState === 'idle' && playbackState === 'idle' && 'Voice mode ready'}
          </span>
        </div>

        {/* Mute Toggle */}
        <button
          onClick={toggleMute}
          className={cn(
            'rounded-lg p-2 transition-colors',
            isMuted
              ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
          )}
          title={isMuted ? 'Unmute interviewer' : 'Mute interviewer'}
        >
          {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>
      </div>

      {/* Transcript Preview */}
      {currentTranscript && (
        <div className="mb-4 rounded-lg bg-slate-800/50 p-3">
          <p className="text-sm text-slate-300">{currentTranscript}</p>
          {interimTranscript && (
            <span className="text-slate-500 animate-pulse">|</span>
          )}
        </div>
      )}

      {/* Audio Level Visualization */}
      {recordingState === 'listening' && (
        <div className="mb-4 flex items-center justify-center gap-1 h-12">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="w-1 rounded-full bg-orange-500 transition-all duration-75"
              style={{
                height: `${Math.max(8, audioLevel * 100 * (0.5 + Math.random() * 0.5))}%`,
                opacity: audioLevel > 0.1 ? 1 : 0.3,
              }}
            />
          ))}
        </div>
      )}

      {/* Control Buttons */}
      <div className="flex items-center justify-center gap-3">
        {recordingState === 'idle' && (
          <>
            {playbackState === 'playing' ? (
              <button
                onClick={stopPlayback}
                className="flex items-center gap-2 rounded-full bg-slate-700 px-6 py-3 text-white hover:bg-slate-600 transition-colors"
              >
                <Square className="h-5 w-5" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                onClick={startRecording}
                disabled={isLoading || playbackState === 'loading'}
                className={cn(
                  'flex items-center gap-2 rounded-full px-6 py-3 text-white transition-all',
                  isLoading || playbackState === 'loading'
                    ? 'bg-slate-700 cursor-not-allowed opacity-50'
                    : 'bg-orange-500 hover:bg-orange-600 hover:scale-105'
                )}
              >
                {playbackState === 'loading' ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Mic className="h-5 w-5" />
                )}
                <span>
                  {playbackState === 'loading' ? 'Loading...' : 'Hold to Speak'}
                </span>
              </button>
            )}
          </>
        )}

        {recordingState === 'listening' && (
          <>
            <button
              onClick={cancelRecording}
              className="flex items-center gap-2 rounded-full bg-slate-700 px-4 py-3 text-slate-300 hover:bg-slate-600 transition-colors"
            >
              <RotateCcw className="h-5 w-5" />
              <span>Cancel</span>
            </button>
            <button
              onClick={stopRecording}
              className="flex items-center gap-2 rounded-full bg-red-500 px-6 py-3 text-white hover:bg-red-600 transition-all animate-pulse"
            >
              <MicOff className="h-5 w-5" />
              <span>Stop & Send</span>
            </button>
          </>
        )}

        {recordingState === 'processing' && (
          <div className="flex items-center gap-2 rounded-full bg-amber-500/20 px-6 py-3 text-amber-400">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Processing...</span>
          </div>
        )}
      </div>

      {/* Help Text */}
      <p className="text-center text-xs text-slate-500 mt-3">
        {recordingState === 'idle' && 'Click the button and speak your response clearly'}
        {recordingState === 'listening' && 'Speak now. Click "Stop & Send" when finished.'}
        {recordingState === 'processing' && 'Converting your speech to text...'}
      </p>
    </div>
  );
}
