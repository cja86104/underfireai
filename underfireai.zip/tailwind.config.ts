import type { Config } from 'tailwindcss';

/**
 * UNDERFIREAI TAILWIND CONFIG
 * ===========================
 * Professional Interview Coaching Theme
 * 
 * Design System:
 * - Deep navy/slate for professionalism
 * - Fire orange/amber for intensity and motivation
 * - Cool grays for balance
 * - High contrast for accessibility
 */

const config: Config = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '1.5rem',
      screens: {
        '2xl': '1400px',
      },
    },
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        sidebar: {
          DEFAULT: 'hsl(var(--sidebar-background))',
          foreground: 'hsl(var(--sidebar-foreground))',
          primary: 'hsl(var(--sidebar-primary))',
          'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
          accent: 'hsl(var(--sidebar-accent))',
          'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
          border: 'hsl(var(--sidebar-border))',
          ring: 'hsl(var(--sidebar-ring))',
        },
        
        // UnderFireAI Brand Palette
        fire: {
          abyss: '#0c0806',
          deepest: '#1a1008',
          darker: '#2d1a0c',
          dark: '#4a2c14',
          DEFAULT: '#d97706',
          light: '#f59e0b',
          lighter: '#fbbf24',
          bright: '#fcd34d',
        },
        navy: {
          abyss: '#030508',
          deepest: '#0a1020',
          darker: '#0f172a',
          dark: '#1e293b',
          DEFAULT: '#334155',
          light: '#475569',
          lighter: '#64748b',
          muted: '#94a3b8',
        },
        slate: {
          50: '#f8fafc',
          100: '#f1f5f9',
          200: '#e2e8f0',
          300: '#cbd5e1',
          400: '#94a3b8',
          500: '#64748b',
          600: '#475569',
          700: '#334155',
          800: '#1e293b',
          900: '#0f172a',
          950: '#020617',
        },
        
        // Interview Score Colors
        score: {
          excellent: '#22c55e',
          good: '#84cc16',
          average: '#eab308',
          poor: '#f97316',
          critical: '#ef4444',
        },
        
        // Interviewer Mood Indicators
        mood: {
          impressed: '#22c55e',
          neutral: '#64748b',
          skeptical: '#f59e0b',
          critical: '#ef4444',
          engaged: '#3b82f6',
        },
        
        // Status Colors
        success: '#22c55e',
        warning: '#f59e0b',
        error: '#ef4444',
        info: '#3b82f6',
      },
      
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
        xl: 'calc(var(--radius) + 4px)',
        '2xl': 'calc(var(--radius) + 8px)',
        '3xl': 'calc(var(--radius) + 16px)',
      },
      
      fontFamily: {
        sans: ['Inter', 'var(--font-sans)', 'system-ui', 'sans-serif'],
        display: ['Inter', 'var(--font-display)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem', letterSpacing: '-0.02em' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem', letterSpacing: '-0.02em' }],
        '5xl': ['3rem', { lineHeight: '3.25rem', letterSpacing: '-0.02em' }],
      },
      
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '26': '6.5rem',
      },
      
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' },
        },
        'fade-in': {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        'fade-out': {
          from: { opacity: '1' },
          to: { opacity: '0' },
        },
        'fade-in-up': {
          from: { opacity: '0', transform: 'translateY(16px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-in-from-bottom': {
          from: { transform: 'translateY(100%)' },
          to: { transform: 'translateY(0)' },
        },
        'slide-in-from-right': {
          from: { transform: 'translateX(100%)' },
          to: { transform: 'translateX(0)' },
        },
        pulse: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.6' },
        },
        'typing-dot': {
          '0%, 100%': { opacity: '0.25', transform: 'scale(0.85)' },
          '50%': { opacity: '1', transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'scale-in': {
          from: { opacity: '0', transform: 'scale(0.95)' },
          to: { opacity: '1', transform: 'scale(1)' },
        },
        'glow-fire': {
          '0%, 100%': { boxShadow: '0 0 25px rgba(217, 119, 6, 0.25)' },
          '50%': { boxShadow: '0 0 45px rgba(217, 119, 6, 0.4)' },
        },
        'timer-pulse': {
          '0%, 100%': { transform: 'scale(1)', color: 'inherit' },
          '50%': { transform: 'scale(1.05)', color: '#ef4444' },
        },
      },
      
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'fade-in': 'fade-in 0.3s ease-out',
        'fade-out': 'fade-out 0.3s ease-out',
        'fade-in-up': 'fade-in-up 0.5s ease-out',
        'slide-in-from-bottom': 'slide-in-from-bottom 0.3s ease-out',
        'slide-in-from-right': 'slide-in-from-right 0.3s ease-out',
        pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'typing-dot': 'typing-dot 1.4s ease-in-out infinite',
        shimmer: 'shimmer 2.5s linear infinite',
        'scale-in': 'scale-in 0.2s ease-out',
        'glow-fire': 'glow-fire 3s ease-in-out infinite',
        'timer-pulse': 'timer-pulse 1s ease-in-out infinite',
      },
      
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'fire-gradient': 'linear-gradient(145deg, #f59e0b 0%, #d97706 50%, #b45309 100%)',
        'fire-gradient-subtle': 'linear-gradient(145deg, rgba(217, 119, 6, 0.08) 0%, rgba(180, 83, 9, 0.08) 100%)',
        'navy-gradient': 'linear-gradient(145deg, #334155 0%, #1e293b 50%, #0f172a 100%)',
        'glow-fire-radial': 'radial-gradient(circle at center, rgba(217, 119, 6, 0.15) 0%, transparent 70%)',
      },
      
      boxShadow: {
        'glow-fire': '0 0 30px rgba(217, 119, 6, 0.25)',
        'glow-fire-lg': '0 0 50px rgba(217, 119, 6, 0.35)',
        'elevation-1': '0 1px 3px rgba(0, 0, 0, 0.12)',
        'elevation-2': '0 3px 8px rgba(0, 0, 0, 0.18)',
        'elevation-3': '0 6px 16px rgba(0, 0, 0, 0.22)',
        'elevation-4': '0 12px 32px rgba(0, 0, 0, 0.28)',
        'card': '0 2px 8px rgba(0, 0, 0, 0.15), 0 0 1px rgba(0, 0, 0, 0.3)',
        'card-hover': '0 8px 24px rgba(0, 0, 0, 0.25), 0 0 1px rgba(0, 0, 0, 0.3)',
      },
      
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};

export default config;
